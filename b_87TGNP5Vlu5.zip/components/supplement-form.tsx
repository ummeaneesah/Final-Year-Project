'use client'

import { useState, useEffect } from 'react'
import { X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useSupplements } from '@/lib/supplements-context'
import { TIMING_LABELS, type Supplement, type MealTiming } from '@/lib/types'

interface SupplementFormProps {
  supplement?: Supplement | null
  onClose: () => void
}

const UNITS = ['mg', 'mcg', 'g', 'IU', 'ml', 'drops', 'capsules', 'tablets', 'softgels']

export function SupplementForm({ supplement, onClose }: SupplementFormProps) {
  const { addSupplement, updateSupplement } = useSupplements()
  const [name, setName] = useState('')
  const [dosage, setDosage] = useState('')
  const [unit, setUnit] = useState('mg')
  const [timing, setTiming] = useState<MealTiming>('with_breakfast')
  const [frequency, setFrequency] = useState<'daily' | 'weekly' | 'as_needed'>('daily')
  const [notes, setNotes] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (supplement) {
      setName(supplement.name)
      setDosage(supplement.dosage)
      setUnit(supplement.unit)
      setTiming(supplement.timing)
      setFrequency(supplement.frequency)
      setNotes(supplement.notes || '')
    }
  }, [supplement])

  const validate = () => {
    const newErrors: Record<string, string> = {}
    if (!name.trim()) newErrors.name = 'Name is required'
    if (!dosage.trim()) newErrors.dosage = 'Dosage is required'
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return

    const data = {
      name: name.trim(),
      dosage: dosage.trim(),
      unit,
      timing,
      frequency,
      notes: notes.trim() || undefined,
    }

    if (supplement) {
      updateSupplement(supplement.id, data)
    } else {
      addSupplement(data)
    }

    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-foreground/20 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-lg bg-card rounded-2xl shadow-xl border border-border overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="text-xl font-display font-semibold text-foreground">
            {supplement ? 'Edit Supplement' : 'Add Supplement'}
          </h2>
          <Button variant="ghost" size="icon-sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 flex flex-col gap-5">
          {/* Name */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="name">Supplement Name</Label>
            <Input
              id="name"
              placeholder="e.g., Vitamin D3"
              value={name}
              onChange={(e) => setName(e.target.value)}
              aria-invalid={!!errors.name}
            />
            {errors.name && (
              <span className="text-sm text-destructive">{errors.name}</span>
            )}
          </div>

          {/* Dosage and Unit */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-2">
              <Label htmlFor="dosage">Dosage</Label>
              <Input
                id="dosage"
                placeholder="e.g., 1000"
                value={dosage}
                onChange={(e) => setDosage(e.target.value)}
                aria-invalid={!!errors.dosage}
              />
              {errors.dosage && (
                <span className="text-sm text-destructive">{errors.dosage}</span>
              )}
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="unit">Unit</Label>
              <Select value={unit} onValueChange={setUnit}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {UNITS.map((u) => (
                    <SelectItem key={u} value={u}>
                      {u}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Timing */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="timing">When to Take</Label>
            <Select value={timing} onValueChange={(v) => setTiming(v as MealTiming)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(TIMING_LABELS).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Frequency */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="frequency">Frequency</Label>
            <Select value={frequency} onValueChange={(v) => setFrequency(v as typeof frequency)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="as_needed">As Needed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Notes */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Input
              id="notes"
              placeholder="e.g., Take with fat for better absorption"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              {supplement ? 'Save Changes' : 'Add Supplement'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
