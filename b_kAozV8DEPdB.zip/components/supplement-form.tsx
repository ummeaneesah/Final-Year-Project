'use client'

import { useState, useEffect, useMemo } from 'react'
import { X, Search, Info } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useSupplements } from '@/lib/supplements-context'
import { TIMING_LABELS, type Supplement, type MealTiming } from '@/lib/types'
import { SUPPLEMENT_DATABASE, findSupplementRule, type SupplementRule } from '@/lib/supplement-data'

interface SupplementFormProps {
  supplement?: Supplement | null
  onClose: () => void
}

export function SupplementForm({ supplement, onClose }: SupplementFormProps) {
  const { addSupplement, updateSupplement } = useSupplements()
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedSupplement, setSelectedSupplement] = useState<SupplementRule | null>(null)
  const [showDropdown, setShowDropdown] = useState(false)
  const [dosage, setDosage] = useState('')
  const [notes, setNotes] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Filter supplements based on search query
  const filteredSupplements = useMemo(() => {
    if (!searchQuery.trim()) return SUPPLEMENT_DATABASE
    const query = searchQuery.toLowerCase()
    return SUPPLEMENT_DATABASE.filter(s => 
      s.name.toLowerCase().includes(query)
    )
  }, [searchQuery])

  // Group supplements by category for better organization
  const groupedSupplements = useMemo(() => {
    const groups: Record<string, SupplementRule[]> = {
      vitamin: [],
      mineral: [],
      herb: [],
      amino_acid: [],
      other: [],
    }
    filteredSupplements.forEach(s => {
      groups[s.category].push(s)
    })
    return groups
  }, [filteredSupplements])

  const categoryLabels: Record<string, string> = {
    vitamin: 'Vitamins',
    mineral: 'Minerals',
    herb: 'Herbs & Botanicals',
    amino_acid: 'Amino Acids',
    other: 'Other Supplements',
  }

  // Load existing supplement data when editing
  useEffect(() => {
    if (supplement) {
      const rule = findSupplementRule(supplement.name)
      if (rule) {
        setSelectedSupplement(rule)
        setSearchQuery(supplement.name)
      } else {
        // Custom supplement not in database
        setSearchQuery(supplement.name)
      }
      setDosage(supplement.dosage)
      setNotes(supplement.notes || '')
    }
  }, [supplement])

  // Auto-fill dosage when supplement is selected
  useEffect(() => {
    if (selectedSupplement && !supplement) {
      setDosage(selectedSupplement.defaultDosage)
      setNotes(selectedSupplement.notes || '')
    }
  }, [selectedSupplement, supplement])

  const handleSelectSupplement = (rule: SupplementRule) => {
    setSelectedSupplement(rule)
    setSearchQuery(rule.name)
    setShowDropdown(false)
    setErrors({})
  }

  const validate = () => {
    const newErrors: Record<string, string> = {}
    if (!selectedSupplement && !searchQuery.trim()) {
      newErrors.name = 'Please select a supplement'
    }
    if (!dosage.trim()) {
      newErrors.dosage = 'Dosage is required'
    }
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return

    // Use selected supplement rules or defaults
    const timing: MealTiming = selectedSupplement?.timing || 'with_breakfast'
    const frequency = selectedSupplement?.frequency || 'daily'
    const unit = selectedSupplement?.unit || 'mg'
    const name = selectedSupplement?.name || searchQuery.trim()

    const data = {
      name,
      dosage: dosage.trim(),
      unit,
      timing,
      frequency,
      notes: notes.trim() || undefined,
    }

    if (supplement) {
      updateSupplement(supplement.id, data)
    } else {
      addSupplement(data)
    }

    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-foreground/20 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-lg bg-card rounded-2xl shadow-xl border border-border overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <h2 className="text-xl font-semibold text-foreground">
            {supplement ? 'Edit Supplement' : 'Add Supplement'}
          </h2>
          <Button variant="ghost" size="icon-sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 flex flex-col gap-5 overflow-y-auto">
          {/* Supplement Search/Select */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="supplement">Select Supplement</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="supplement"
                placeholder="Search for a supplement..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value)
                  setShowDropdown(true)
                  if (selectedSupplement && e.target.value !== selectedSupplement.name) {
                    setSelectedSupplement(null)
                  }
                }}
                onFocus={() => setShowDropdown(true)}
                className="pl-10"
                aria-invalid={!!errors.name}
              />
              
              {/* Dropdown */}
              {showDropdown && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-xl shadow-lg z-10 max-h-64 overflow-y-auto">
                  {filteredSupplements.length === 0 ? (
                    <div className="p-4 text-center text-muted-foreground text-sm">
                      No supplements found. You can still add a custom supplement.
                    </div>
                  ) : (
                    Object.entries(groupedSupplements).map(([category, supplements]) => {
                      if (supplements.length === 0) return null
                      return (
                        <div key={category}>
                          <div className="px-3 py-2 text-xs font-semibold text-muted-foreground bg-muted/50 sticky top-0">
                            {categoryLabels[category]}
                          </div>
                          {supplements.map((rule) => (
                            <button
                              key={rule.name}
                              type="button"
                              onClick={() => handleSelectSupplement(rule)}
                              className="w-full px-4 py-2.5 text-left hover:bg-primary/10 transition-colors flex items-center justify-between gap-2"
                            >
                              <span className="font-medium text-foreground">{rule.name}</span>
                              <span className="text-xs text-muted-foreground">
                                {rule.defaultDosage} {rule.unit}
                              </span>
                            </button>
                          ))}
                        </div>
                      )
                    })
                  )}
                </div>
              )}
            </div>
            {errors.name && (
              <span className="text-sm text-destructive">{errors.name}</span>
            )}
          </div>

          {/* Auto-filled info display */}
          {selectedSupplement && (
            <div className="p-4 rounded-xl bg-primary/10 border border-primary/20 flex flex-col gap-3">
              <div className="flex items-center gap-2 text-sm font-medium text-primary">
                <Info className="w-4 h-4" />
                Auto-calculated schedule
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-muted-foreground">When to take:</span>
                  <p className="font-medium text-foreground">{TIMING_LABELS[selectedSupplement.timing]}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Frequency:</span>
                  <p className="font-medium text-foreground capitalize">{selectedSupplement.frequency.replace('_', ' ')}</p>
                </div>
              </div>
              {selectedSupplement.notes && (
                <p className="text-xs text-muted-foreground italic">{selectedSupplement.notes}</p>
              )}
            </div>
          )}

          {/* Dosage */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="dosage">
              Dosage {selectedSupplement && `(${selectedSupplement.unit})`}
            </Label>
            <Input
              id="dosage"
              placeholder={selectedSupplement ? `Recommended: ${selectedSupplement.defaultDosage}` : 'Enter dosage'}
              value={dosage}
              onChange={(e) => setDosage(e.target.value)}
              aria-invalid={!!errors.dosage}
            />
            {errors.dosage && (
              <span className="text-sm text-destructive">{errors.dosage}</span>
            )}
          </div>

          {/* Notes */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="notes">Additional Notes (Optional)</Label>
            <Input
              id="notes"
              placeholder="Any personal notes..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              {supplement ? 'Save Changes' : 'Add Supplement'}
            </Button>
          </div>
        </form>
      </div>
      
      {/* Click outside to close dropdown */}
      {showDropdown && (
        <div 
          className="fixed inset-0 z-[45]" 
          onClick={() => setShowDropdown(false)}
        />
      )}
    </div>
  )
}
