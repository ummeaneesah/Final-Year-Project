import { type MealTiming } from './types'

export interface SupplementRule {
  name: string
  defaultDosage: string
  unit: string
  timing: MealTiming
  frequency: 'daily' | 'weekly' | 'as_needed'
  notes?: string
  category: 'vitamin' | 'mineral' | 'herb' | 'amino_acid' | 'other'
}

// This data structure will be populated with your Excel data
// For now, it contains common supplements with their recommended timing
export const SUPPLEMENT_DATABASE: SupplementRule[] = [
  // Fat-soluble vitamins - take with meals containing fat
  {
    name: 'Vitamin D3',
    defaultDosage: '1000',
    unit: 'IU',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Take with a meal containing fat for better absorption',
    category: 'vitamin',
  },
  {
    name: 'Vitamin E',
    defaultDosage: '400',
    unit: 'IU',
    timing: 'with_dinner',
    frequency: 'daily',
    notes: 'Fat-soluble, take with food',
    category: 'vitamin',
  },
  {
    name: 'Vitamin A',
    defaultDosage: '5000',
    unit: 'IU',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Fat-soluble vitamin',
    category: 'vitamin',
  },
  {
    name: 'Vitamin K2',
    defaultDosage: '100',
    unit: 'mcg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Take with Vitamin D for synergy',
    category: 'vitamin',
  },

  // Water-soluble vitamins - can take anytime, better on empty stomach
  {
    name: 'Vitamin C',
    defaultDosage: '500',
    unit: 'mg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Can be taken with or without food',
    category: 'vitamin',
  },
  {
    name: 'Vitamin B12',
    defaultDosage: '1000',
    unit: 'mcg',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Best absorbed on an empty stomach',
    category: 'vitamin',
  },
  {
    name: 'B-Complex',
    defaultDosage: '1',
    unit: 'capsules',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Take in the morning for energy boost',
    category: 'vitamin',
  },
  {
    name: 'Folate',
    defaultDosage: '400',
    unit: 'mcg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Important for cell division',
    category: 'vitamin',
  },
  {
    name: 'Biotin',
    defaultDosage: '5000',
    unit: 'mcg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Supports hair, skin, and nails',
    category: 'vitamin',
  },

  // Minerals
  {
    name: 'Iron',
    defaultDosage: '18',
    unit: 'mg',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Take on empty stomach with Vitamin C. Avoid with calcium or coffee.',
    category: 'mineral',
  },
  {
    name: 'Magnesium Glycinate',
    defaultDosage: '200',
    unit: 'mg',
    timing: 'bedtime',
    frequency: 'daily',
    notes: 'Promotes relaxation and better sleep',
    category: 'mineral',
  },
  {
    name: 'Magnesium Citrate',
    defaultDosage: '200',
    unit: 'mg',
    timing: 'with_dinner',
    frequency: 'daily',
    notes: 'Good for digestive support',
    category: 'mineral',
  },
  {
    name: 'Calcium',
    defaultDosage: '500',
    unit: 'mg',
    timing: 'with_dinner',
    frequency: 'daily',
    notes: 'Take separately from iron. Pair with Vitamin D.',
    category: 'mineral',
  },
  {
    name: 'Zinc',
    defaultDosage: '15',
    unit: 'mg',
    timing: 'with_dinner',
    frequency: 'daily',
    notes: 'Take with food to avoid nausea. Separate from copper.',
    category: 'mineral',
  },
  {
    name: 'Selenium',
    defaultDosage: '200',
    unit: 'mcg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Supports thyroid function',
    category: 'mineral',
  },
  {
    name: 'Chromium',
    defaultDosage: '200',
    unit: 'mcg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Helps with blood sugar regulation',
    category: 'mineral',
  },
  {
    name: 'Iodine',
    defaultDosage: '150',
    unit: 'mcg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Supports thyroid health',
    category: 'mineral',
  },

  // PCOS-specific supplements
  {
    name: 'Inositol (Myo-Inositol)',
    defaultDosage: '2000',
    unit: 'mg',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Key supplement for PCOS support. Take on empty stomach.',
    category: 'other',
  },
  {
    name: 'D-Chiro-Inositol',
    defaultDosage: '50',
    unit: 'mg',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Often combined with Myo-Inositol for PCOS',
    category: 'other',
  },
  {
    name: 'Berberine',
    defaultDosage: '500',
    unit: 'mg',
    timing: 'before_dinner',
    frequency: 'daily',
    notes: 'Supports blood sugar and metabolism',
    category: 'herb',
  },
  {
    name: 'NAC (N-Acetyl Cysteine)',
    defaultDosage: '600',
    unit: 'mg',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Antioxidant support, take on empty stomach',
    category: 'amino_acid',
  },
  {
    name: 'Spearmint',
    defaultDosage: '500',
    unit: 'mg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'May help with androgen levels in PCOS',
    category: 'herb',
  },

  // Omega fatty acids
  {
    name: 'Omega-3 Fish Oil',
    defaultDosage: '1000',
    unit: 'mg',
    timing: 'with_dinner',
    frequency: 'daily',
    notes: 'Take with a fatty meal for absorption',
    category: 'other',
  },
  {
    name: 'Evening Primrose Oil',
    defaultDosage: '1000',
    unit: 'mg',
    timing: 'with_dinner',
    frequency: 'daily',
    notes: 'Supports hormonal balance',
    category: 'other',
  },

  // Probiotics
  {
    name: 'Probiotic',
    defaultDosage: '10',
    unit: 'capsules',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Take on empty stomach for best colonization',
    category: 'other',
  },

  // Adaptogens and herbs
  {
    name: 'Ashwagandha',
    defaultDosage: '300',
    unit: 'mg',
    timing: 'bedtime',
    frequency: 'daily',
    notes: 'Adaptogen for stress and sleep support',
    category: 'herb',
  },
  {
    name: 'Rhodiola',
    defaultDosage: '200',
    unit: 'mg',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Take in the morning for energy. Avoid late in day.',
    category: 'herb',
  },
  {
    name: 'Maca',
    defaultDosage: '1500',
    unit: 'mg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Supports hormonal balance and energy',
    category: 'herb',
  },
  {
    name: 'Turmeric/Curcumin',
    defaultDosage: '500',
    unit: 'mg',
    timing: 'with_dinner',
    frequency: 'daily',
    notes: 'Anti-inflammatory. Take with black pepper for absorption.',
    category: 'herb',
  },
  {
    name: 'Ginger',
    defaultDosage: '500',
    unit: 'mg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Supports digestion and reduces inflammation',
    category: 'herb',
  },

  // Amino acids
  {
    name: 'L-Carnitine',
    defaultDosage: '500',
    unit: 'mg',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Supports energy metabolism',
    category: 'amino_acid',
  },
  {
    name: 'L-Glutamine',
    defaultDosage: '5000',
    unit: 'mg',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Gut health support. Take on empty stomach.',
    category: 'amino_acid',
  },
  {
    name: 'Glycine',
    defaultDosage: '3000',
    unit: 'mg',
    timing: 'bedtime',
    frequency: 'daily',
    notes: 'Supports sleep quality',
    category: 'amino_acid',
  },

  // Other common supplements
  {
    name: 'CoQ10',
    defaultDosage: '100',
    unit: 'mg',
    timing: 'with_breakfast',
    frequency: 'daily',
    notes: 'Fat-soluble, take with food',
    category: 'other',
  },
  {
    name: 'Alpha Lipoic Acid',
    defaultDosage: '300',
    unit: 'mg',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Best absorbed on empty stomach',
    category: 'other',
  },
  {
    name: 'Collagen',
    defaultDosage: '10',
    unit: 'g',
    timing: 'before_breakfast',
    frequency: 'daily',
    notes: 'Take on empty stomach or with Vitamin C',
    category: 'other',
  },
  {
    name: 'Melatonin',
    defaultDosage: '3',
    unit: 'mg',
    timing: 'bedtime',
    frequency: 'as_needed',
    notes: 'Take 30 minutes before sleep',
    category: 'other',
  },
]

// Helper function to find a supplement by name
export function findSupplementRule(name: string): SupplementRule | undefined {
  const lowerName = name.toLowerCase()
  return SUPPLEMENT_DATABASE.find(s => 
    s.name.toLowerCase() === lowerName ||
    s.name.toLowerCase().includes(lowerName) ||
    lowerName.includes(s.name.toLowerCase())
  )
}

// Get unique supplement names for autocomplete
export function getSupplementNames(): string[] {
  return SUPPLEMENT_DATABASE.map(s => s.name)
}

// Get supplements by category
export function getSupplementsByCategory(category: SupplementRule['category']): SupplementRule[] {
  return SUPPLEMENT_DATABASE.filter(s => s.category === category)
}
