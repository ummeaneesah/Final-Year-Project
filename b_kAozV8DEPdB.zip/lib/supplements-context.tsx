'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import type { Supplement } from './types'

interface SupplementsContextType {
  supplements: Supplement[]
  addSupplement: (supplement: Omit<Supplement, 'id' | 'createdAt'>) => void
  updateSupplement: (id: string, supplement: Partial<Supplement>) => void
  deleteSupplement: (id: string) => void
  clearAllSupplements: () => void
  isLoading: boolean
}

const SupplementsContext = createContext<SupplementsContextType | undefined>(undefined)

export function SupplementsProvider({ children }: { children: ReactNode }) {
  const [supplements, setSupplements] = useState<Supplement[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const saved = localStorage.getItem('supplement_scheduler_data')
    if (saved) {
      const parsed = JSON.parse(saved)
      setSupplements(parsed.map((s: Supplement) => ({
        ...s,
        createdAt: new Date(s.createdAt)
      })))
    }
    setIsLoading(false)
  }, [])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('supplement_scheduler_data', JSON.stringify(supplements))
    }
  }, [supplements, isLoading])

  const addSupplement = (supplement: Omit<Supplement, 'id' | 'createdAt'>) => {
    const newSupplement: Supplement = {
      ...supplement,
      id: crypto.randomUUID(),
      createdAt: new Date(),
    }
    setSupplements(prev => [...prev, newSupplement])
  }

  const updateSupplement = (id: string, updates: Partial<Supplement>) => {
    setSupplements(prev => 
      prev.map(s => s.id === id ? { ...s, ...updates } : s)
    )
  }

  const deleteSupplement = (id: string) => {
    setSupplements(prev => prev.filter(s => s.id !== id))
  }

  const clearAllSupplements = () => {
    setSupplements([])
  }

  return (
    <SupplementsContext.Provider value={{ 
      supplements, 
      addSupplement, 
      updateSupplement, 
      deleteSupplement,
      clearAllSupplements,
      isLoading 
    }}>
      {children}
    </SupplementsContext.Provider>
  )
}

export function useSupplements() {
  const context = useContext(SupplementsContext)
  if (context === undefined) {
    throw new Error('useSupplements must be used within a SupplementsProvider')
  }
  return context
}
